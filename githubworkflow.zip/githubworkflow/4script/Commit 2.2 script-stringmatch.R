#-----------------------------------------------------------------------#
#                      stringmatch-siteselect-nv                        #
#-----------------------------------------------------------------------#
# Script purpose:                                                       #
#  # The source script for "2.1 script-stringmatch-wrapperfunction.R"   #
#  # Compile site selection & company info. Use regrex to identify      #
#    string patterns and extract elements from them.                    # 
#  # Result is a df that's structured to be merged in the 2.1 R script. #
#-----------------------------------------------------------------------#

########## PRELIMS ########## 

# Bring in packages
library(readr)

# Set file paths
#path.dlpdf <- ("C:/.../githubworkflow/1downloadspdf")
#path.dltxt <- ("C:/.../githubworkflow/2downloadspdf")

# Bring in data
setwd(path.dlpdf)       #set wd to where PDF files are saved
listfiles <- list.files(pattern = "pdf$")       #get file list
length <- length(listfiles)         #run a sample for now

########## P2. STRING MATCHING FOR TEXT MINING ########## 

# 1. SITE SELECTION FACTORS. String pattern: starts ALRU, 1 digit, starts TSBA, :, 1 digit. 
ssf <- as.data.frame(appl %>% 
                       str_subset(pattern = "[\\<A|L|R|U].*\\:.*(?<![0-9])[0-9](?![0-9])\\s.*[\\<T|S|B|A].*\\:.*[1-5]") %>% 
                       str_c(collapse = "\n") %>% 
                       read_table(col_names = FALSE)) 
# rename columns
names(ssf)
colnames(ssf) <- c("factor1", "rating1","factor2", "rating2")
ssf$ID <- row.names(ssf)

# reshape wide to long
ssf <- reshape(ssf, direction='long',
               varying=c("factor1", "rating1", "factor2", "rating2"),
               timevar = 'var',
               times = c('rating', 'factor'),
               v.names=c('rating', 'factor'),
               idvar='ID')

ssf <- ssf[c("factor", "rating")]         #keep two columns
ssf$factor <- sub(":", "", ssf$factor)    #remove ":"

# Ready to create the main df.

# extract by transposing ssf to create the main df
df <- setNames(data.frame(t(ssf[,-1])), ssf[,1])

# 2. COMPANY NAME. String pattern: includes "Board Summary" and "Date".
string.companyname <- appl %>%
  str_subset(pattern = ".*Board Summary *(.*?) *Date.*")

string.companyname <- string.companyname[!duplicated(string.companyname)]

# extract element between "Board Summary" and "Date"
df$companyname <- sub(".*Board Summary *(.*?) *Date.*", "\\1", string.companyname)

# 3. MEETING DATE. String pattern: recycle string above
#extract element following the ":"
df$date <- sub(".*:", "", string.companyname)
df$date <- gsub("^\\s+|\\s+$", "", df$date)             # remove newline
#df$date <- sub("//s+", " ", df$date)          # trim white space

# 4. GROWTH TYPE. String pattern: includes "Business Type"
string.growthtype <- appl %>%
  str_subset(pattern = "Business Type:")

#extract element btwn "Type: " & "County" 
df$growthtype <- sub(".*Business Type:(.*?) *County.*", "\\1", string.growthtype) 

# 5. COUNTY. String pattern: recycle string above
#extract element btwn "County" & "Development"
df$county <- sub(".*County:(.*?) *Development.*", "\\1", string.growthtype) 

# 6. INDUSTRY. String pattern: identify row number that has "NAICS CODE" in it AND the row below it.
naicsrow <- appl %>%
  grep(pattern = "NAICS CODE")

string.naics <- appl %>%
  str_split(pattern = "\n") %>% 
  unlist() %>% 
  str_c(collapse = "\n") %>% 
  read_table(col_names = FALSE)

string.naics <- string.naics[c(naicsrow, naicsrow +1), ]
string.naics <- paste(string.naics$X1, collapse="")

# Extract the first set of digits of any length.
df$naics <- as.numeric(str_extract(string.naics, "\\d+")) %>% 
  unlist()

# Extract just first 2 digits (i.e., industry super sector code)
df$naics2dig <- str_sub(df$naics, 1, 2) 

# Create lookup table to add Industry
naics2dig <- c("11", "21", "22", "23", "31", "32", "33", "42", "44", "45", "48", "49", "51", "52", "53", "54", "55", "56", "61", "62", "71", "72", "81", "99")
naics2ind <- c("Agriculture, forestry, fishing and hunting", "Mining, quarrying, and oil and gas extraction", "Utilities", "Construction", "Manufacturing", "Manufacturing", "Manufacturing", "Wholesale trade", "Retail trade", "Retail trade", "Transportation and warehousing", "Transportation and warehousing", "Information", "Finance and insurance", "Real estate and rental and leasing", "Professional, scientific, and technical services", "Management of companies and enterprises", "Administrative and waste services", "Educational services", "Health care and social assistance", "Arts, entertainment, and recreation", "Accommodation and food services", "Other services, except public administration", "Unclassified")
lookup <- data.frame(naics2dig, naics2ind)
df <- left_join(df, lookup)

# Reorder columns and done
names(df)
df <- df[,c(13:19,1:12)]

# (the remaining work for df will be executed by the "2.1 script".)


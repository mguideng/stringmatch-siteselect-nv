#----------------------------------------------------------------#
#                   stringmatch-siteselect-nv                    #
#----------------------------------------------------------------#
# Script purpose:                                                #
#  # Convert company applications from PDF --> text to screen    #
#    whether site selection factors (ssf) info is present.       #
#  # Evaluate to True/False for each application, identified by  #
#    list order of where files are saved within the filepath.    #
#  # Output is "ssfboolean.csv".                                 #
#----------------------------------------------------------------#

########## PRELIMS ########## 
library(pdftools)
library(stringr)
library(beepr)

# Set working directory to where the PDF source data is saved (the 1downloadspdf subfolder):  
#path.dlpdf <- ("C:/.../1downloadspdf")
setwd(path.dlpdf)
listfiles <- list.files(pattern = "pdf$")       #get list of objects

########## SCREEN ########## 
# First, create empty list
datalist <- list()

# The screening for loop to apply function calls to the collection of objects
for (i in 1:length(dir(path.dlpdf))){
  application <- pdf_text(paste(path.dlpdf, "/", listfiles[i], sep="")) #function usage takes filthpath with the pdf data.
  application <- paste(application, collapse = "")
  datalist[[i]] <- application
  datalist[[i]]$boolean <- grepl(application, pattern = "Site Selection Factors")
  }

# Combine by rows
big.datalist <- do.call(rbind, datalist) %>% 
  as.data.frame()

# Variable - File ID
big.datalist$fileID <- row.names(big.datalist)

# Variable - Boolean
class(big.datalist$boolean)  #flatten list (otherwise, won't write to csv)
big.datalist$boolean <- as.character(big.datalist$boolean) 

########## NEXT STEPS ########## 
# Export
ssfboolean <- big.datalist[c("fileID", "boolean")]
write.csv(ssfboolean, "ssfboolean.csv", row.names = F)

beep(6) #"I'm not ready, beep!" We're not ready to move forward until the false applications are removed:
# Examine those identified as False, verify lack of SSF info, and omit by removing from folder.
# Then, ready to run the next script: "2.1 script-stringmatch-wrapperfunction.R"

